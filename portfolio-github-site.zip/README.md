# Jonathan Quinones — Portfolio

Static site (no build step). Files:

- `index.html` — the page
- `styles.css` — the stylesheet
- `assets/` — all photos, logos, posters and videos

Keep `index.html`, `styles.css` and the `assets` folder together in the same folder (repository root).

## Publish on GitHub Pages
1. Create a repository, upload everything in this folder to the root (drag & drop works).
2. Settings → Pages → Source: "Deploy from a branch", Branch: `main`, folder `/ (root)` → Save.
3. After a minute the site is live at `https://<username>.github.io/<repository>/`.

Contact form: set `FORM_ENDPOINT` near the top of the script in `index.html` (e.g. a free Formspree URL) to receive messages.
